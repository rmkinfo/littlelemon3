from django.contrib import admin
from restaurant import models
from models import Booking , Menu

# Register your models here.
admin.site.register(Booking)
admin.site.register(Menu)